class siswa {
    constructor(nama, umur, kelas){
        this.nama = nama;
        this.umur = umur;
        this.kelas = kelas;
    }

    menulis() {
        return 'gerakan ${this.umur} ${this.nama} menulis';
    }

    membaca() {
        return 'gerakan ${this.umur} ${this.nama} membaca';
    }

     menggambar() {
        return 'gerakan ${this.umur} ${this.nama} menggambar';
    }
}

    let siswa1 = new siswa("Rudi", "19", 12);
    let siswa2 = new siswa("Carli", "16", 10);
    let siswa3 = new siswa("lanang", "18", 11);
    
    console.log(siswa1.menulis());
    console.log(siswa2.membaca());
    console.log(siswa3.menggambar());
