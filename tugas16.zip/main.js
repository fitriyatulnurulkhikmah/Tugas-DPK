class kendaraan {
    constructor(model, merk, harga){
        this.model = model;
        this.merk = merk;
        this.harga = harga;
    }

    maju() {
        return 'mesin ${this.merk} ${this.model} berjalan maju';
    }

    berhenti() {
        return 'mesin ${this.merk} ${this.model} berhenti';
    }
}

    let mobil = new kendaraan("Supra", "Toyota", 200000);
    let motor = new kendaraan("CBR", "Honda", 30000);
    
    console.log(mobil.maju());
    console.log(motor.berhenti());
